const { applyGuards, azdo, PROJECT, WIT_INITIATIVE, FIELD_STORYPOINTS, FIELD_PRIORITY, SQUAD_AREA } = require('../../../lib/azure');

module.exports = async (req, res) => {
  if (!applyGuards(req, res)) return;
  try {
    const squadId = req.query.squadId;
    const area = SQUAD_AREA[squadId];
    if (!area) return res.status(404).json({ error: 'squad desconhecida' });

    // 1. WIQL: IDs sob o Area Path da squad
    const wiql = {
      query:
        `SELECT [System.Id] FROM WorkItems ` +
        `WHERE [System.TeamProject] = '${PROJECT}' ` +
        `AND [System.AreaPath] UNDER '${area.replace(/\\/g, '\\\\')}' ` +
        `AND [System.WorkItemType] IN ('${WIT_INITIATIVE}','Epic','Feature','User Story') ` +
        `ORDER BY [${FIELD_PRIORITY}] ASC`,
    };
    const wiqlRes = await azdo('wit/wiql', { method: 'POST', body: wiql });
    const ids = (wiqlRes.workItems || []).map(w => w.id);
    if (ids.length === 0) return res.status(200).json({ squad: squadId, items: [] });

    // 2. Detalhes em lote, paginando de 200 em 200 (limite da API)
    const allValues = [];
    for (let i = 0; i < ids.length; i += 200) {
      const chunk = ids.slice(i, i + 200);
      const batch = await azdo('wit/workitemsbatch', {
        method: 'POST',
        body: { ids: chunk, $expand: 'Relations' },
      });
      (batch.value || []).forEach(v => allValues.push(v));
    }

    const items = allValues.map(wi => {
      let parent = wi.fields['System.Parent'] || null;
      if (!parent && Array.isArray(wi.relations)) {
        const pr = wi.relations.find(r => r.rel === 'System.LinkTypes.Hierarchy-Reverse');
        if (pr) parent = parseInt(pr.url.split('/').pop());
      }
      return {
        id: wi.id,
        type: wi.fields['System.WorkItemType'],
        title: wi.fields['System.Title'],
        state: wi.fields['System.State'],
        desc: wi.fields['System.Description'] || '',
        parent,
        iteration: wi.fields['System.IterationPath'] || null,
        area: wi.fields['System.AreaPath'] || null,
        storyPoints: wi.fields[FIELD_STORYPOINTS] ?? null,
        priority: wi.fields[FIELD_PRIORITY] ?? null,
      };
    });

    res.status(200).json({ squad: squadId, items });
  } catch (e) {
    console.error(e);
    res.status(e.status || 500).json({ error: e.message });
  }
};
