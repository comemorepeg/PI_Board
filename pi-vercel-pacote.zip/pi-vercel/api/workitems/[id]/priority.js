const { applyGuards, patchWorkItemSafe, FIELD_PRIORITY } = require('../../../lib/azure');

// PATCH /api/workitems/:id/priority
module.exports = async (req, res) => {
  if (!applyGuards(req, res)) return;
  if (req.method !== 'PATCH') return res.status(405).json({ error: 'use PATCH' });
  try {
    const id = req.query.id;
    const { priority } = req.body || {};
    if (priority == null) return res.status(400).json({ error: 'priority obrigatório' });
    const updated = await patchWorkItemSafe(id, () => ([
      { op: 'add', path: `/fields/${FIELD_PRIORITY}`, value: priority },
    ]));
    res.status(200).json({ id: updated.id, rev: updated.rev, priority: updated.fields[FIELD_PRIORITY] ?? null });
  } catch (e) {
    console.error(e);
    res.status(e.status || 500).json({ error: e.message, conflict: e.status === 409 });
  }
};
