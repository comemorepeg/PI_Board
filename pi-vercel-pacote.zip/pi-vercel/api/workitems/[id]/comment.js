const { applyGuards, azdo } = require('../../../lib/azure');

// GET  /api/workitems/:id/comment  → lê comentários (reconstrói riscos/bloqueios/obs)
// POST /api/workitems/:id/comment  → cria comentário (risco/bloqueio/obs prefixado)
module.exports = async (req, res) => {
  if (!applyGuards(req, res)) return;
  const id = req.query.id;
  try {
    if (req.method === 'POST') {
      const { text } = req.body || {};
      if (!text) return res.status(400).json({ error: 'text obrigatório' });
      const created = await azdo(`wit/workItems/${id}/comments`, {
        method: 'POST', body: { text }, apiVersion: '7.1-preview.3',
      });
      return res.status(200).json({ id: created.id, text: created.text });
    }
    if (req.method === 'GET') {
      const data = await azdo(`wit/workItems/${id}/comments`, { apiVersion: '7.1-preview.3' });
      const comments = (data.comments || []).map(c => ({
        id: c.id, text: c.text, createdBy: c.createdBy?.displayName, createdDate: c.createdDate,
      }));
      return res.status(200).json({ comments });
    }
    res.status(405).json({ error: 'use GET ou POST' });
  } catch (e) {
    console.error(e);
    res.status(e.status || 500).json({ error: e.message });
  }
};
