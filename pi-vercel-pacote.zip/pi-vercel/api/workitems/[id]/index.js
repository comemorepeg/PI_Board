const { applyGuards, patchWorkItemSafe, FIELD_STORYPOINTS } = require('../../../lib/azure');

// PATCH /api/workitems/:id  — atualiza story points / título / descrição (com System.Rev)
module.exports = async (req, res) => {
  if (!applyGuards(req, res)) return;
  if (req.method !== 'PATCH') return res.status(405).json({ error: 'use PATCH' });
  try {
    const id = req.query.id;
    const { storyPoints, title, description } = req.body || {};
    if (storyPoints === undefined && title === undefined && description === undefined)
      return res.status(400).json({ error: 'nada para atualizar' });

    const updated = await patchWorkItemSafe(id, () => {
      const ops = [];
      if (storyPoints !== undefined) ops.push({ op: 'add', path: `/fields/${FIELD_STORYPOINTS}`, value: storyPoints });
      if (title !== undefined) ops.push({ op: 'add', path: '/fields/System.Title', value: title });
      if (description !== undefined) ops.push({ op: 'add', path: '/fields/System.Description', value: description });
      return ops;
    });
    res.status(200).json({ id: updated.id, rev: updated.rev, storyPoints: updated.fields[FIELD_STORYPOINTS] ?? null });
  } catch (e) {
    console.error(e);
    res.status(e.status || 500).json({ error: e.message, conflict: e.status === 409 });
  }
};
