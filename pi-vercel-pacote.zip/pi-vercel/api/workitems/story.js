const { applyGuards, azdo, ORG, FIELD_STORYPOINTS, SQUAD_AREA } = require('../../lib/azure');

// POST /api/workitems/story  — cria User Story vinculada ao parent (Feature) + story points
module.exports = async (req, res) => {
  if (!applyGuards(req, res)) return;
  if (req.method !== 'POST') return res.status(405).json({ error: 'use POST' });
  try {
    const { squadId, parentId, title, description, storyPoints, iterationPath } = req.body || {};
    const area = SQUAD_AREA[squadId];
    if (!area) return res.status(400).json({ error: 'squad inválida' });
    if (!title) return res.status(400).json({ error: 'title obrigatório' });

    const ops = [
      { op: 'add', path: '/fields/System.Title', value: title },
      { op: 'add', path: '/fields/System.AreaPath', value: area },
    ];
    if (description) ops.push({ op: 'add', path: '/fields/System.Description', value: description });
    if (storyPoints != null) ops.push({ op: 'add', path: `/fields/${FIELD_STORYPOINTS}`, value: storyPoints });
    if (iterationPath) ops.push({ op: 'add', path: '/fields/System.IterationPath', value: iterationPath });
    if (parentId) {
      ops.push({ op: 'add', path: '/relations/-', value: {
        rel: 'System.LinkTypes.Hierarchy-Reverse',
        url: `https://dev.azure.com/${ORG}/_apis/wit/workItems/${parentId}`,
      }});
    }

    const created = await azdo(`wit/workitems/$User%20Story`, {
      method: 'POST', body: ops, contentType: 'application/json-patch+json',
    });
    res.status(200).json({
      id: created.id, title: created.fields['System.Title'],
      storyPoints: created.fields[FIELD_STORYPOINTS] ?? null, parent: parentId || null,
    });
  } catch (e) {
    console.error(e);
    res.status(e.status || 500).json({ error: e.message });
  }
};
