const { applyGuards, ORG, PROJECT } = require('../lib/azure');

module.exports = (req, res) => {
  if (!applyGuards(req, res)) return;
  res.status(200).json({ ok: true, org: ORG, project: PROJECT });
};
