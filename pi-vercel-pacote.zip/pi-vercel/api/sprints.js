const { applyGuards, azdo, API } = require('../lib/azure');

module.exports = async (req, res) => {
  if (!applyGuards(req, res)) return;
  try {
    const data = await azdo('wit/classificationnodes/iterations?$depth=5', { apiVersion: API });
    const flat = [];
    (function walk(node) {
      const a = node.attributes || {};
      if (a.startDate && /sprint\s*\d+/i.test(node.name)) {
        flat.push({ name: node.name, path: node.path || node.name, start: a.startDate, finish: a.finishDate || null });
      }
      (node.children || []).forEach(walk);
    })(data);

    // Filtro PI Brasil: sprints sob \Releases\ dentro do horizonte de datas
    const FROM = process.env.SPRINT_FROM || '2026-07-01';
    const TO   = process.env.SPRINT_TO   || '2027-02-01';
    const RELEASES_PATH = process.env.SPRINT_PATH || 'Releases';

    const sprints = flat
      .filter(it => (it.path || '').includes(RELEASES_PATH))
      .filter(it => it.start >= FROM && it.start < TO)
      .map(it => {
        const d = new Date(it.start);
        return { id: it.name, name: it.name, path: it.path, start: it.start, finish: it.finish,
          quarter: d.getUTCMonth() >= 9 ? 'Q4' : 'Q3' };
      })
      .sort((a, b) => (a.start || '').localeCompare(b.start || ''));

    res.status(200).json({ sprints });
  } catch (e) {
    console.error(e);
    res.status(e.status || 500).json({ error: e.message });
  }
};
